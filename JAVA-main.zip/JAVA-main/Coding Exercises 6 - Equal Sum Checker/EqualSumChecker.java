public class EqualSumChecker {
    public static boolean hasEqualSum(int i1,int i2,int i3){
        if((i1+i2) == i3){
            return true;
        }else{
            return false;
        }
    }
}